from NetworkInterface import NetworkInterfaceSettings as Settings



ints = Settings()
print(ints.set())